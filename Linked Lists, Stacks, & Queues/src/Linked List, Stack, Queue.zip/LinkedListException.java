public class LinkedListException extends Exception{

    public LinkedListException()
    {
        super();
    }

    public LinkedListException(String msg)
    {
        super(msg);
    }
}
