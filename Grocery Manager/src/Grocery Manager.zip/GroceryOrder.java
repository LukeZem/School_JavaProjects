/**
 * @author Luke
 * CSS 143 B
 * Grocery Manager HW
 */
/**
 * Extends ArrayList and implements generic
 */

import java.util.ArrayList;

public class GroceryOrder<T> extends ArrayList<GroceryItem> {
}
